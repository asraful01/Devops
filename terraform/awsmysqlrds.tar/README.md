## RDS - Relation Database Services

. It's a managed database solution:
  . You can easily setup replication (high availability)
  . Automated snapshots (for backups)
  . Automated security updates
  . Easy instance replacement (for vertical scaling)

. Supported databases are:
  . MySQL
  . MariaDB
  . PostgreSQL
  . Microsoft SQL
  . Oracle

. Steps to create an RDS instance:
  . create a subnet group
    . Allows you to specify in what subnets the database will be in (e.g. us-west-1a, us-west-1b, us-west-1c)
  . Create a parameter group
    . Allows you to specify parameters to change settings in the database
  . Create a security group that allows incoming traffic to the RDS instance
  . Create the RDS instance(s) itself


# sudo apt-get install mysql-client
# mysql -u root -h <db--hostname-here> -p 'myRandomPassword2019'
# show databases
# \q

# host <db--hostname-here>
