## Creating a VPC and Security Group and launching a new instance in it
